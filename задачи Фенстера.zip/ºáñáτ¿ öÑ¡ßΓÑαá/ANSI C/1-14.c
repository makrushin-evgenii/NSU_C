/*Упражнение 1.14. Программа для вывода гистограммы частот, с которыми встречаются во входном потоке различные символы*/ 
#include <stdio.h>

int main()
{
	int count[255];
	for (int i = 0; i < 255; ++i)
		count[i] = 0;

	int c;
	while((c = getchar()) != EOF)
		++count[c];

	// вывод горизонтальной гистограммы
	for (int i = 0; i < 255; ++i)
		if (count[i] > 0){
			printf("'%c': ", i);
			for (int j = 0; j < count[i]; ++j)
				putchar('X');
			printf("(%d)\n", count[i]);
		}

}