/*Упражнение 1.13. Программа для вывода гистограммы длин слов во входном потоке*/ 
#include <stdio.h>
#define IN 1
#define OUT 0

int main()
{
	int state = OUT;
	int cur_count = 0;

	int len[32];
	for (int i = 0; i < 32; ++i)
		len[i] = 0;

	int c;
	while((c = getchar()) != EOF){	
		//вышел из слова
		if (c == ' '){
			++len[cur_count];
			state = OUT;
			cur_count = 0;
		}
		// встретил слово
		else if (state == OUT){
			state = IN;
		}

		// накопление счетчика
		if (state == IN){
			cur_count++;
		}
	}

	// вывод горизонтальной гистограммы
	for (int i = 0; i < 32; ++i)
		if (len[i] > 0){
			printf("%d: ", i);
			for (int j = 0; j < len[i]; ++j)
				putchar('X');
			printf(" (%d)", len[i]);
			putchar('\n');
		}			
}